﻿'use strict';

swptApp.service('favoritesService', [
    '$http', 'configService', function($http, configService) {


    }
]);

