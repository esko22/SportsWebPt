﻿'use strict';

var adminModule = angular.module('admin.module', [
    'body.region.admin.module',
    'body.part.admin.module',
    'prognosis.admin.module',
    'treatment.admin.module',
    'equipment.admin.module',
    'cause.admin.module',
    'sign.admin.module',
    'video.admin.module',
    'exercise.admin.module',
    'plan.admin.module',
    'injury.admin.module'
]);
